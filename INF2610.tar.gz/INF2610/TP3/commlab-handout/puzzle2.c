/*
 * Comm Lab - puzzle2.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------

#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include "libcommlab.h"
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>


#define R 0
#define W 1

// -------------------------------------------------

void puzzle2() {
    // TODO
    int fd[2];
    int check = pipe(fd);
    if(check==-1){
    	perror("Erreur creation pipe");
    	exit(EXIT_FAILURE);
    }

    int cpid = fork();
    if(cpid==0){
		close(fd[W]);
   		char fd_arg[100];
   		snprintf(fd_arg, sizeof(fd_arg), "%d", fd[R]);
    	execl("./puzzle2/telegraph", "telegraph", fd_arg, NULL);
    }else if(cpid == -1){
    	perror("Erreur du fork");
    	exit(EXIT_FAILURE);
    }
    close(fd[R]);

    unsigned char buf[30] = { 141, 153, 32, 148, 143, 139, 133, 142, 32, 137, 147, 32, 
    	197, 192, 199, 196, 130, 199, 196, 133, 190, 131, 197, 193, 32, 147, 148, 143, 144, 0 };
    write(fd[W], buf, 30);
    close(fd[W]);
    wait(NULL);
}