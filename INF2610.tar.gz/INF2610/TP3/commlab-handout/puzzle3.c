/*
 * Comm Lab - puzzle3.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------

#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include "libcommlab.h"
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>


#define R 0
#define W 1

// -------------------------------------------------

void puzzle3() {
    // TODO
    int fd[2];
    pipe(fd);
    int open_file;
    if(vfork()==0){
    	open_file = open("./puzzle3/tmpfile", O_RDWR);
    	close(fd[W]);
    	close(fd[R]);
    	dup2(STDOUT_FILENO, STDERR_FILENO);
    	dup2(open_file, STDOUT_FILENO);
    	execl("./puzzle3/exc1","exc1", NULL);
    }else if(vfork()==0){
    	open_file = open("./puzzle3/tmpfile", O_RDWR);
    	close(fd[R]);
		dup2(STDOUT_FILENO, STDERR_FILENO);
		dup2(fd[W], STDOUT_FILENO);
    	execl("./puzzle3/exc2", "exc2", NULL);
    }else if(fork()==0){
    	open_file = open("./puzzle3/tmpfile", O_RDWR);
    	close(fd[W]);
    	dup2(fd[R], STDIN_FILENO);
    	execl("./puzzle3/exc3", "exc3", NULL);
    }else if(vfork()==0){
    	open_file = open("./puzzle3/tmpfile", O_RDWR);
    	close(fd[R]);
    	close(fd[W]);
    	dup2(open_file, STDIN_FILENO);
		dup2(STDOUT_FILENO, STDERR_FILENO);
    	execl("./puzzle3/exc4", "exc4", NULL);

    }
    close(fd[W]);
    close(fd[R]);
    wait(NULL);
    wait(NULL);
    wait(NULL);
    wait(NULL);


}