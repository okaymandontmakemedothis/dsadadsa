m/*
 * Comm Lab - puzzle1.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include "libcommlab.h"
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
// -------------------------------------------------


void puzzle1() {
    // TODO
    char* token = "e77856d502bf";
    mkfifo("/tmp/pipe_0ead177d", S_IRWXU);
    mkfifo("/tmp/pipe_cb1e9fdf", S_IRWXU);
    int cpid = fork();
    if(cpid==0){
    	execl("./puzzle1/exchanger", "exchanger", NULL);
    }else if(cpid == -1){
    	perror("Erreur du fork");
    	exit(EXIT_FAILURE);
    }
	
	int n,fd = open("/tmp/pipe_0ead177d", O_WRONLY);
	if(fd != -1){
		//Transmission de token
		write(fd, token, strlen(token)+1);
		close(fd);
	}else{
		perror("Erreur d'ouverture du tube nomme");
		exit(EXIT_FAILURE);
	}

	//Envoyer un signal au fils
	kill(cpid, SIGUSR1);
	fd = open("/tmp/pipe_cb1e9fdf", O_RDONLY);

	char message[100];
	while((n=read(fd, message, 100))>0){
	}
	checkExchangerMessage(message);

	remove("/tmp/pipe_0ead177d");
	remove("/tmp/pipe_cb1e9fdf");
	return ;
}