/*
 * Comm Lab - puzzle1.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _PUZZLE1_H
#define _PUZZLE1_H

void puzzle1();

#endif