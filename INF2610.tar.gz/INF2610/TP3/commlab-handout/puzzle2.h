/*
 * Comm Lab - puzzle2.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _PUZZLE2_H
#define _PUZZLE2_H

void puzzle2();

#endif