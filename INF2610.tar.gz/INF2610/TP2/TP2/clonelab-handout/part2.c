/*
 * Clone Lab - part2.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#include "libclonelab.h"

#include <stdio.h>

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>	
#include <stdio.h>
// -------------------------------------------------

#define PART2_OUTPUT_FILE_PATH "part2Output.txt"

void part2() {
    // Ouverture du fichier de sortie pour la question 2.3
    FILE* part2OutputFile = fopen(PART2_OUTPUT_FILE_PATH, "w");
    // TODO
    //level0
    char ptrPID[5];
    pid_t pid_level_0 = getpid();
    fprintf(part2OutputFile, "Root process has pid %d ", pid_level_0);
    if(fork()==0){
    	//level1.1

    	registerProc(1,1,getpid(),getppid());
    	if(fork()==0){
    		//level2.1
    		registerProc(2,1,getpid(),getppid());
	    	fprintf(part2OutputFile, "(message from process level2.1)\n");
	    	fclose(part2OutputFile);
		   	sprintf(ptrPID,"%d",getppid());
    		execl("./part2/level2.1", "level2.1", ptrPID, NULL);
    		exit(0);
    	}
    	wait(NULL);
	   	sprintf(ptrPID,"%d",getppid());
    	execl("./part2/level1.1", "level1.1", ptrPID, NULL);
    	exit(0);
    }
    if(fork()==0){
    	//level1.2
    	registerProc(1,2,getpid(),getppid());
    	if(fork()==0){
    		//level2.2
    		registerProc(2,2,getpid(),getppid());
		   	sprintf(ptrPID,"%d",getppid());
    		execl("./part2/level2.2", "level2.2", ptrPID, NULL);
    		exit(0);
    	}
    	wait(NULL);
    	fprintf(part2OutputFile, "(message from process level1.2)\n");
    	fclose(part2OutputFile);
	   	sprintf(ptrPID,"%d",getppid());
    	execl("./part2/level1.2", "level1.2", ptrPID, NULL);
    	exit(0);
    }
    if(fork()==0){
    	//level1.3
    	registerProc(1,3,getpid(),getppid());
    	if(fork()==0){
    		//level2.3
    		registerProc(2,3,getpid(),getppid());
	    	fprintf(part2OutputFile, "(message from process level2.3)\n");
	    	fclose(part2OutputFile);
		   	sprintf(ptrPID,"%d",getppid());
			execl("./part2/level2.3", "level2.3", ptrPID, NULL);
    		exit(0);
    	}
		wait(NULL);
    	if(fork()==0){
    		//level2.4
    		registerProc(2,4,getpid(),getppid());
	    	fprintf(part2OutputFile, "(message from process level2.4)\n");
	    	fclose(part2OutputFile);
		   	sprintf(ptrPID,"%d",getppid());
    		execl("./part2/level2.4", "level2.4", ptrPID, NULL);
    		exit(0);
    	}
    	wait(NULL);
    	fprintf(part2OutputFile, "(message from process level1.3)\n");
    	fclose(part2OutputFile);
	   	sprintf(ptrPID,"%d",getppid());
		execl("./part2/level1.3", "level1.3", ptrPID, NULL);
    	exit(0);
    }
    if(fork()==0){
    	//level1.4
    	registerProc(1,4,getpid(),getppid());
    	if(fork()==0){
    		//level2.5
    		registerProc(2,5,getpid(),getppid());
		   	sprintf(ptrPID,"%d",getppid());
			execl("./part2/level2.5", "level2.5", ptrPID, NULL);
    		exit(0);
    	}
    	wait(NULL);
	   	sprintf(ptrPID,"%d",getppid());
		execl("./part2/level1.4", "level1.4", ptrPID, NULL);
    	exit(0);
    }
    fprintf(part2OutputFile,"(message from process level0)\n");
    wait(NULL);
    wait(NULL);
    wait(NULL);
    wait(NULL);
    fclose(part2OutputFile);
	execl("./part2/level0", "level0", "73a05aa0ac2b60b685f2c34f", NULL);
}