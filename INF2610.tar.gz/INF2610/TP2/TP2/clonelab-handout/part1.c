/*
 * Clone Lab - part1.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
// -------------------------------------------------

void part1() {
    // TODO
    pid_t pid = fork();
	char ptrPid[5];
    if(pid == 0){
    	//action fils
    	sprintf(ptrPid, "%d",getppid());
	   	execl("./part1/rudolph","rudolph","--pid",ptrPid,NULL); 
		exit(0);    	
	}
	sprintf(ptrPid, "%d",pid);
	execl("./part1/nohemi","nohemi","--pid",ptrPid,NULL);
}