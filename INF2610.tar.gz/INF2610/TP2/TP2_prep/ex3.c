#include <stdio.h>
#include <stdint.h>
#include <pthread.h>
#include <inttypes.h>
#include <unistd.h>
#include <sys/types.h>
// #include <cstdlib>
#include <stdlib.h>

#define MAX 100000000 // 100 millions
static uint64_t a = 0;
void *count(void *arg) {
 volatile uint64_t *var = (uint64_t *) arg;
 volatile uint64_t i;
 for (i = 0; i < MAX; i++) {
 *var = *var + 1;
 }
 return NULL;
}
int main(int argc, char **argv) {
 int p;
 int i;
 pthread_t t1;
 pthread_t t2;
 pthread_create(&t1, NULL, count, &a);
 pthread_create(&t2, NULL, count, &a);
 count(&a);
 pthread_join(t1, NULL);
 pthread_join(t2, NULL);
 printf("pid=%d a=%" PRId64 "\n", getpid(), a);
 return EXIT_SUCCESS;
}