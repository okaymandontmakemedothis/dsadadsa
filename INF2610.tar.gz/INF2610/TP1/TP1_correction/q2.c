/*
 * Init Lab - q2.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------

// CORRECTION

// #include <unistd.h>
// #include <stdio.h>

// -------------------------------------------------

/*
 * Vous devez imprimer le message indiqué dans l'énoncé:
 * - En exécutant un premier appel à printf AVANT l'appel à write
 * - Sans utiliser la fonction fflush
 * - En terminant chaque ligne par le caractère '\n' de fin de ligne
 */
#include <unistd.h>
#include <stdio.h>

void question2() {
    // TODOcl
    printf("f61b4fd35164 (printed using printf)");
    write(1,"f61b4fd35164 (printed using write)\n",35);
    printf("\n");
}