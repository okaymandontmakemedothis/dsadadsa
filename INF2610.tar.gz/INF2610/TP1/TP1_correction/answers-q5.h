/*
 * Init Lab - answers-q5.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H

// -----------------------------------------------------------------
// Reportez ici les réponses que vous avez trouvées à la question 5.
// -----------------------------------------------------------------

// Report here the answer for question 5. a)
char Q5_ANS_A[] = "/tmp/filewriter_secret_c46666d5472f0a31"; //TODO

// Report here the answer for question 5. b)
char Q5_ANS_B[] = "/tmp/filewriter_secret_child_b684ebf084201af7"; //TODO

// Report here the answer for question 5. c)
char Q5_ANS_C[] = "75bb5b7a9cbab266bd7863da0971b18bd44327f058615884ca1f6f53327e6564"; //TODO

// Report here the answer for question 5. d)
char Q5_ANS_D[] = "fputs"; //TODO

// Report here the answer for question 5. e)
char Q5_ANS_E[] = "SLEEP_TIME"; //TODO

#endif